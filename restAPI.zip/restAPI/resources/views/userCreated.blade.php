<p> Hello {{ $user->name }}</p>
<p> Your account has beeen successfully created. </p>
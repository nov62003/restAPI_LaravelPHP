<p> Hi Admin</p>
<p> A new user has beeen created: {{ $user->email }} ({{ $user->name }}). </p>
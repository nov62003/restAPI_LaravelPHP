<p> Hello <?php echo e($user->name); ?></p>
<p> Your account has beeen successfully created. </p><?php /**PATH D:\laragon\www\restAPI\resources\views/userCreated.blade.php ENDPATH**/ ?>